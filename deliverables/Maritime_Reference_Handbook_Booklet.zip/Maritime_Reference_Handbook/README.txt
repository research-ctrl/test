Bennet & Bernard SBD - Maritime Regulatory Reference Handbook (Edition 1, checked 25 Nov 2026)

Maritime_Reference_Handbook_B5.pdf  : the booklet, 23 pages, ISO B5 (176 x 250 mm). Clickable source links.
page_images/page_01.png ... page_23.png : each page as an image (200 dpi, 1386 x 1969 px) for viewing on a phone or pasting into slides.

Pages: 1 cover, 2 how to use, 3 card index, 4-22 cards 01-19, 23 abbreviations.
Confidential. Internal planning reference, not legal advice. Confirm with the flag Administration and Bureau Veritas before purchase.
